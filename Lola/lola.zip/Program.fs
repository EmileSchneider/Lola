﻿open System

open System.IO
open System.Threading
open Binance.Net.Interfaces.Clients.GeneralApi
open Binance.Net.Objects.Models.Spot.Socket
open CryptoExchange.Net.Sockets
open Lola.TradingEngine
open Lola.AlphaEngine
open Lola.TradingEngine.TradingStateMachine

[<EntryPoint>]
let main argv =
    let balances: BinanceTrading.Balances =
        BinanceTrading.getBalances ()
        |> Async.RunSynchronously

    let lastPrice =
        BinanceTrading.client.SpotApi.ExchangeData.GetPriceAsync("BTCUSDT")
        |> Async.AwaitTask
        |> Async.RunSynchronously

    let mutable (previousSignal: Option<TradeSignal>) =
        None

    let amount =
        Decimal.Round(100.0m / lastPrice.Data.Price, 5, MidpointRounding.ToZero)

    let entryLong =
        BinanceTrading.entryLong amount

    let entryShort =
        BinanceTrading.entryShort amount

    let exitLong =
        BinanceTrading.exitLong amount

    let exitShort =
        BinanceTrading.exitShort amount

    let handleNewClose close =
        async {
            AutoRegressionModel.NewClose(close)

            let prediction =
                AutoRegressionModel.Predict()

            let signal =
                BinanceTrading.newSignal close prediction

            Console.WriteLine($"New Close: {close} Signal: {signal}")

            match previousSignal with
            | None -> 0 |> ignore
            | Some signal ->
                match signal with
                | Bullish -> do! exitLong close
                | Bearish -> do! exitShort close

            Thread.Sleep(50)
            match signal with
            | Bullish -> do! entryLong close
            | Bearish -> do! entryShort close

            previousSignal <- Some signal
        }
        |> Async.StartImmediate

    let handleOrderUpdate (update: DataEvent<BinanceStreamOrderUpdate>) =
        Console.WriteLine($"[Order Update]\t {update.Data.Side} {update.Data.ExecutionType} {update.Data.QuantityFilled} ")

    let userStreamKey =
        BinanceTrading.getUserDataStreamKey ()
        |> Async.RunSynchronously

    let balanceUpdateHandler update = 0 |> ignore

    let userStreamSub =
        StreamListeners.userDataSub userStreamKey handleOrderUpdate balanceUpdateHandler

    let klineSub =
        StreamListeners.klineSub handleNewClose

    let closes =
        BinanceTrading.getLastFiveCloses
        |> Async.RunSynchronously

    for c in closes do
        AutoRegressionModel.NewClose c

    [| userStreamSub; klineSub |]
    |> Async.Parallel
    |> Async.Ignore
    |> Async.RunSynchronously

    Console.ReadLine() |> ignore
    0
